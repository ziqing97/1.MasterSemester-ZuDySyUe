function [dy] = dy(t,y)
    dy = t^2 + 2 * t - y + 1; 
end